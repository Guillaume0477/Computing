/* Fichier: serveur.c
 * Communication client-serveur
 * Auteurs: John Samuel, ...
 */


#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "serveur.h"

/* renvoyer un message (*data) au client (client_socket_fd)
 */
int renvoie_message(int client_socket_fd, char *data) {
  int data_size = write (client_socket_fd, (void *) data, strlen(data));
      
  if (data_size < 0) {
    perror("erreur ecriture");
    return(EXIT_FAILURE);
  }
}

/* accepter la nouvelle connection d'un client et lire les données
 * envoyées par le client. Ensuite, le serveur envoie un message
 * en retour
 */
int recois_envoie_message(int socketfd) {
  struct sockaddr_in client_addr;
  char data[1024];

  int client_addr_len = sizeof(client_addr);
 
  // nouvelle connection de client
  int client_socket_fd = accept(socketfd, (struct sockaddr *) &client_addr, &client_addr_len);
  if (client_socket_fd < 0 ) {
    perror("accept");
    return(EXIT_FAILURE);
  }

  memset(data, 0, sizeof(data));

  //lecture de données envoyées par un client
  int data_size = read (client_socket_fd, (void *) data, sizeof(data));
      
  if (data_size < 0) {
    perror("erreur lecture");
    return(EXIT_FAILURE);
  }
        
  printf ("Message recu: %s\n", data);
  char code[10];
  sscanf(data, "%s:", code);

  //Si le message commence par le mot: 'message:' 
  if (strcmp(code, "message:") == 0) {
    printf("Message à renvoyer au client :\n");
    fgets(data, 1024, stdin);
    renvoie_message(client_socket_fd, data);
  }

  //fermer le socket 
  close(socketfd);
}

int recois_numeros_calcule(int socketfd) {
  struct sockaddr_in client_addr;
  char data[1024];

  int client_addr_len = sizeof(client_addr);
 
  // nouvelle connection de client
  int client_socket_fd = accept(socketfd, (struct sockaddr *) &client_addr, &client_addr_len);
  if (client_socket_fd < 0 ) {
    perror("accept");
    return(EXIT_FAILURE);
  }

  int i;
  //Boucle permettant au serveur de répondre à plusieurs demandes
  for (i = 0; i < 55; i++) {
	  memset(data, 0, sizeof(data));
	  //lecture de données envoyées par un client
	  int data_size = read (client_socket_fd, (void *) data, sizeof(data));
	      
	  if (data_size < 0) {
	    perror("erreur lecture");
	    return(EXIT_FAILURE);
	  }
		
	  printf ("Calcul à faire : %s.\n", data);
	  char code[10];
	  sscanf(data, "%s:", code);

	  //Si le message commence par le mot: 'calcul:' 
	  if (strcmp(code, "calcul:") == 0) {
	    char *token;
	    token = strtok(data ," ");
	    token = strtok(NULL ," ");
	    char operator = *token;
	    token = strtok(NULL ," ");
	    double num1 = atof(token);
	    token = strtok(NULL ," ");
	  
	    double resultat;

	    if (token != NULL) {
			double num2 = atof(token);
			switch((int) operator) {
				case (int) '+' : resultat = num1 + num2;break;
				case (int) '-' : resultat = num1 - num2;break;
				case (int) '*' : resultat = num1 * num2;break;
				case (int) '/' : resultat = num1 / num2;break;
				case (int) '&' : resultat = num1 && num2;break;
				case (int) '|' : resultat = num1 || num2;break;
			}
		} else if (operator == '!') {
			resultat = !num1;
		} else { 
			printf("Error");
			return(EXIT_FAILURE);
		}

	    sprintf(data, "%g", resultat);

	    renvoie_message(client_socket_fd, data);
	  }
  }

  //fermer le socket 
  close(socketfd);
}


int main() {

  int socketfd;
  int bind_status;
  int client_addr_len;

  struct sockaddr_in server_addr, client_addr;

  /*
   * Creation d'un socket
   */
  socketfd = socket(AF_INET, SOCK_STREAM, 0);
  if ( socketfd < 0 ) {
    perror("Unable to open a socket");
    return -1;
  }

  int option = 1;
  setsockopt(socketfd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));

  //détails du serveur (adresse et port)
  memset(&server_addr, 0, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT);
  server_addr.sin_addr.s_addr = INADDR_ANY;

  bind_status = bind(socketfd, (struct sockaddr *) &server_addr, sizeof(server_addr));
  if (bind_status < 0 ) {
    perror("bind");
    return(EXIT_FAILURE);
  }
 
  listen(socketfd, 10);
  //recois_envoie_message(socketfd); 
  recois_numeros_calcule(socketfd);
  return 0;
}

