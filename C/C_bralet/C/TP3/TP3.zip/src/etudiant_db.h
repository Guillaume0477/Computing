char lire_fichier(char *);
char ecrire_dans_fichier(char *, char *);
