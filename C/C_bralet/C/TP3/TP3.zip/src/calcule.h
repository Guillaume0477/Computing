int somme(int,int);
int difference(int,int);
int produit(int,int);
float quotient(int,int);
int modulus(int,int);
int etlogique(int,int);
int oulogique(int,int);
int negation(int);

