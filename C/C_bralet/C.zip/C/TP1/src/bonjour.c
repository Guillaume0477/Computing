#include <stdio.h>

int main() {
	printf("Bonjour le monde !!!\n");
	return(0);
}
